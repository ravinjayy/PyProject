import tkinter as tk
window = tk.Tk()
label1 = tk.Label(text="Name")
entry = tk.Entry()
label1.pack()
entry.pack()



